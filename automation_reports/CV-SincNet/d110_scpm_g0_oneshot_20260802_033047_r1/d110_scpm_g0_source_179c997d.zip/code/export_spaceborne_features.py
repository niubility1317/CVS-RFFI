#!/usr/bin/env python
"""Export checkpoint features and WiSig metadata for spaceborne few-shot eval."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import torch
from torch.utils.data import DataLoader


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()

CODE_ROOT = Path(__file__).resolve().parent
REPO_ROOT = CODE_ROOT.parent
# Keep CODE_ROOT ahead of the legacy top-level package directory. When this
# script is executed directly, CODE_ROOT may already be sys.path[0]; remove both
# candidates first so the final order is deterministic.
for path in (str(CODE_ROOT), str(REPO_ROOT)):
    while path in sys.path:
        sys.path.remove(path)
for path in (str(REPO_ROOT), str(CODE_ROOT)):
    sys.path.insert(0, path)

from cvsrffi.wisig_fewshot_payload import assert_disjoint_tx_sets, canonical_tx_id, parse_tx_id_list
from cvsrffi.checkpoint_loading import build_exact_ssdg_model_from_checkpoint
from cvsrffi.identity_only_forward import (
    can_use_identity_only_forward,
    identity_only_feature_forward,
)
from cvsrffi.eval import apply_sat_channel_for_scenario
from cvsrffi.tensors import make_torch_generator
from dataset_wisig import WiSigCompactDataset, WiSigSubsetDataset, load_wisig_compact_pkl
from eval_feature_diagnosis import collect_feature_dict, parse_items
from training_controls import parse_sat_scenarios, sat_channel_config_for_scenario

SIMPLIFIED_LEO_RESIDUAL_SCENARIOS = {"leo_clear_weak", "leo_low_elev_weak", "leo_rain_weak"}
SATELLITE_TTA_POLICIES = (
    "none",
    "repair_canonical1",
    "rx_shift3",
    "rx_cfo3",
    "rx_light5",
    "sat_rx_phys11",
    "sat_rx_blind15",
    "sat_rx_repair9",
    "sat_rx_repair_anchor7",
)


def _validate_star_ground_impl(impl: str, scenarios: Sequence[str], *, field: str) -> None:
    impl_text = str(impl or "legacy_satellite")
    if impl_text != "simplified_leo_residual":
        return
    unexpected = sorted(set(str(s) for s in scenarios) - SIMPLIFIED_LEO_RESIDUAL_SCENARIOS)
    if unexpected:
        allowed = ",".join(sorted(SIMPLIFIED_LEO_RESIDUAL_SCENARIOS))
        raise ValueError(
            f"{field} uses star_ground_channel_impl=simplified_leo_residual but includes "
            f"non-simplified scenarios={unexpected}; allowed={allowed}"
        )


def _spectral_logmag_sketch_batch(raw_rows: np.ndarray, *, dim: int) -> np.ndarray:
    """Build deterministic FFT log-magnitude descriptors from one IQ view."""
    raw = np.asarray(raw_rows, dtype=np.float32)
    if raw.ndim != 3 or raw.shape[1] != 2:
        raise ValueError(f"expected IQ batch shaped [N,2,T], got {raw.shape}")
    target_x = np.linspace(0.0, 1.0, int(dim), dtype=np.float64)
    rows: list[np.ndarray] = []
    for row in raw:
        complex_iq = row[0].astype(np.float64) + 1j * row[1].astype(np.float64)
        complex_iq = complex_iq - np.mean(complex_iq)
        rms = float(np.sqrt(np.mean(np.abs(complex_iq) ** 2)))
        if rms > 1.0e-8:
            complex_iq = complex_iq / rms
        window = np.hanning(int(complex_iq.size))
        if float(np.max(window)) <= 0.0:
            window = np.ones(int(complex_iq.size), dtype=np.float64)
        spectrum = np.fft.fftshift(np.fft.fft(complex_iq * window))
        logmag = np.log1p(np.abs(spectrum)).astype(np.float64)
        source_x = np.linspace(0.0, 1.0, int(logmag.size), dtype=np.float64)
        sketch = np.interp(target_x, source_x, logmag).astype(np.float32)
        sketch -= np.mean(sketch, dtype=np.float64).astype(np.float32)
        sketch /= np.maximum(float(np.linalg.norm(sketch)), 1.0e-8)
        rows.append(sketch.astype(np.float32))
    return np.stack(rows, axis=0).astype(np.float32)


def _rf_statistics_batch(raw_rows: np.ndarray) -> np.ndarray:
    """Build a 32-D gain-normalized IQ fingerprint from one physical view."""
    raw = np.asarray(raw_rows, dtype=np.float32)
    if raw.ndim != 3 or raw.shape[1] != 2:
        raise ValueError(f"expected IQ batch shaped [N,2,T], got {raw.shape}")
    rows: list[np.ndarray] = []
    eps = 1.0e-8
    for row in raw:
        z = row[0].astype(np.float64) + 1j * row[1].astype(np.float64)
        rms = float(np.sqrt(np.mean(np.abs(z) ** 2)))
        if rms > eps:
            z = z / rms
        centered = z - np.mean(z)
        centered_rms = float(np.sqrt(np.mean(np.abs(centered) ** 2)))
        if centered_rms > eps:
            centered = centered / centered_rms

        i = z.real
        q = z.imag
        std_i = float(np.std(i))
        std_q = float(np.std(q))
        iq_corr = (
            float(np.mean((i - np.mean(i)) * (q - np.mean(q))) / (std_i * std_q))
            if std_i > eps and std_q > eps
            else 0.0
        )
        amp = np.abs(z)
        amp_mean = float(np.mean(amp))
        amp_std = float(np.std(amp))
        amp_centered = amp - amp_mean
        amp_skew = float(np.mean(amp_centered**3) / max(amp_std**3, eps))
        amp_kurt = float(np.mean(amp_centered**4) / max(amp_std**4, eps))

        values: list[float] = [
            float(np.mean(i)),
            float(np.mean(q)),
            std_i,
            std_q,
            iq_corr,
            amp_mean,
            amp_std,
            *[float(v) for v in np.quantile(amp, [0.10, 0.25, 0.50, 0.75, 0.90])],
            float(np.max(amp)),
            amp_skew,
            amp_kurt,
        ]
        for order, include_abs in ((2, True), (3, False), (4, True)):
            moment = complex(np.mean(centered**order))
            values.extend([float(moment.real), float(moment.imag)])
            if include_abs:
                values.append(float(abs(moment)))
        for lag in (1, 2, 4, 8):
            if centered.size <= lag:
                corr = 0.0j
            else:
                corr = complex(np.mean(centered[lag:] * np.conj(centered[:-lag])))
            values.extend([float(corr.real), float(corr.imag)])
        if amp.size > 1 and amp_std > eps:
            amp_corr1 = float(
                np.mean(amp_centered[1:] * amp_centered[:-1]) / max(amp_std**2, eps)
            )
        else:
            amp_corr1 = 0.0
        values.append(amp_corr1)
        descriptor = np.asarray(values, dtype=np.float32)
        if descriptor.shape != (32,):
            raise AssertionError(f"RF descriptor dimension drifted: {descriptor.shape}")
        if not np.isfinite(descriptor).all():
            raise ValueError("RF descriptor contains non-finite values")
        descriptor /= np.maximum(float(np.linalg.norm(descriptor)), eps)
        rows.append(descriptor)
    return np.stack(rows, axis=0).astype(np.float32)


def _resolve_tx_indices(tx_list: Sequence[Any], spec: str | None, *, field: str) -> tuple[list[int], list[str]]:
    requested = parse_tx_id_list(spec)
    if not requested:
        raise ValueError(f"{field} must not be empty")
    labels = [canonical_tx_id(v) for v in tx_list]
    out_idx: list[int] = []
    out_labels: list[str] = []
    for item in requested:
        found = None
        try:
            raw_i = int(item)
        except Exception:
            raw_i = None
        if raw_i is not None and 0 <= raw_i < len(labels):
            found = raw_i
        else:
            for i, label in enumerate(labels):
                if label == item:
                    found = i
                    break
        if found is None:
            raise ValueError(f"cannot resolve {field} item {item!r} from tx_list={labels}")
        out_idx.append(int(found))
        out_labels.append(labels[int(found)])
    return out_idx, out_labels


def _resolve_indices(name_list: Sequence[Any], spec: str | None) -> list[int] | None:
    items = parse_items(spec)
    if items is None:
        return None
    labels = [canonical_tx_id(v) for v in name_list]
    out: list[int] = []
    for item in items:
        found = None
        if isinstance(item, int) and 0 <= item < len(labels):
            found = int(item)
        else:
            s = canonical_tx_id(item)
            for i, label in enumerate(labels):
                if label == s:
                    found = i
                    break
        if found is None:
            raise ValueError(f"cannot resolve {item!r} from {labels}")
        out.append(int(found))
    return sorted(set(out))


def _cap_dataset_per_tx(
    ds: WiSigCompactDataset,
    max_samples_per_tx: int,
    seed: int,
    split_source: str,
    *,
    exclude_source_record_indices: set[int] | None = None,
):
    if int(max_samples_per_tx) <= 0:
        return ds
    excluded = {
        int(value) for value in (exclude_source_record_indices or set())
    }
    by_tx: dict[int, list[int]] = {}
    for i, it in enumerate(ds.index):
        if int(i) in excluded:
            continue
        by_tx.setdefault(int(it.tx_i), []).append(int(i))
    rng = np.random.default_rng(int(seed))
    selected: list[int] = []
    for tx_i in sorted(by_tx):
        idx = by_tx[tx_i]
        if len(idx) < int(max_samples_per_tx):
            raise ValueError(
                "insufficient independent physical rows after reference-cache "
                f"exclusion: tx_i={tx_i} available={len(idx)} "
                f"required={int(max_samples_per_tx)}"
            )
        if len(idx) > int(max_samples_per_tx):
            pick = rng.permutation(len(idx))[: int(max_samples_per_tx)].tolist()
            idx = sorted(idx[int(i)] for i in pick)
        selected.extend(idx)
    return WiSigSubsetDataset(ds, sorted(selected), split_source=split_source)


def _build_wisig_dataset(
    *,
    pkl_path: str,
    tx_spec: str,
    role: str,
    equalized: str,
    out_len: int,
    domain: str,
    days: str | None,
    rxs: str | None,
    max_samples_per_combo: int,
    max_samples_per_tx: int,
    seed: int,
    dataset_cache: dict[str, dict[str, Any]] | None = None,
    exclude_source_record_indices: set[int] | None = None,
):
    cache_key = str(Path(pkl_path).resolve())
    if dataset_cache is not None and cache_key in dataset_cache:
        ds = dataset_cache[cache_key]
    else:
        ds = load_wisig_compact_pkl(pkl_path)
        if dataset_cache is not None:
            dataset_cache[cache_key] = ds
    tx_idx, tx_labels = _resolve_tx_indices(ds.get("tx_list", []), tx_spec, field=f"{role}_tx_ids")
    day_keep = _resolve_indices(ds.get("capture_date_list", []), days)
    rx_keep = _resolve_indices(ds.get("rx_list", []), rxs)
    base = WiSigCompactDataset(
        ds,
        out_len=int(out_len),
        equalized=("both" if str(equalized).lower() == "both" else int(equalized)),
        tx_keep=tx_idx,
        day_keep=day_keep,
        rx_keep=rx_keep,
        domain=str(domain),
        max_samples_per_combo=(None if int(max_samples_per_combo) <= 0 else int(max_samples_per_combo)),
        sample_strategy="random",
        seed=int(seed),
        build_index=True,
    )
    capped = _cap_dataset_per_tx(
        base,
        int(max_samples_per_tx),
        int(seed),
        split_source=f"{role}_max_per_tx",
        exclude_source_record_indices=exclude_source_record_indices,
    )
    info = {
        "pkl": str(pkl_path),
        "role": role,
        "tx_idx": tx_idx,
        "tx_labels": tx_labels,
        "days": days,
        "rxs": rxs,
        "size": len(capped),
        "excluded_source_record_count": len(
            exclude_source_record_indices or set()
        ),
    }
    return capped, info


def _meta_to_list(meta: Any, key: str, n: int) -> list[str]:
    if not isinstance(meta, dict) or key not in meta:
        return [""] * int(n)
    value = meta[key]
    if torch.is_tensor(value):
        return [canonical_tx_id(v) for v in value.detach().cpu().reshape(-1).tolist()]
    if isinstance(value, np.ndarray):
        return [canonical_tx_id(v) for v in value.reshape(-1).tolist()]
    if isinstance(value, (list, tuple)):
        return [canonical_tx_id(v) for v in value]
    return [canonical_tx_id(value)] * int(n)


def _to_complex_iq(x: torch.Tensor) -> torch.Tensor:
    if torch.is_complex(x):
        return x
    if x.dim() < 3 or x.size(1) != 2:
        raise ValueError("IQ tensor must be complex or real shaped [B,2,T]")
    return torch.complex(x[:, 0].float(), x[:, 1].float())


def _from_complex_iq(z: torch.Tensor, like: torch.Tensor) -> torch.Tensor:
    if torch.is_complex(like):
        return z
    return torch.stack([z.real, z.imag], dim=1).to(dtype=like.dtype)


def _rms_normalize_iq(x: torch.Tensor, *, clip_sigma: float | None = None) -> torch.Tensor:
    if torch.is_complex(x):
        z = x
        rms = torch.sqrt(torch.mean(torch.abs(z) ** 2, dim=-1, keepdim=True).clamp_min(1e-8))
        if clip_sigma is not None:
            limit = float(clip_sigma) * rms
            mag = torch.abs(z).clamp_min(1e-8)
            z = z * torch.clamp(limit / mag, max=1.0)
        out_rms = torch.sqrt(torch.mean(torch.abs(z) ** 2, dim=-1, keepdim=True).clamp_min(1e-8))
        return (z / out_rms).to(dtype=x.dtype)
    rms = torch.sqrt(torch.mean(x.float() ** 2, dim=(1, 2), keepdim=True).clamp_min(1e-8))
    y = x.float()
    if clip_sigma is not None:
        y = torch.clamp(y, min=-float(clip_sigma) * rms, max=float(clip_sigma) * rms)
    out_rms = torch.sqrt(torch.mean(y ** 2, dim=(1, 2), keepdim=True).clamp_min(1e-8))
    return (y / out_rms).to(dtype=x.dtype)


def _short_fir_smooth_iq(x_sat: torch.Tensor) -> torch.Tensor:
    z = _to_complex_iq(x_sat)
    # Conservative receive-side equalization hypothesis; no new channel is
    # synthesized, only a local smoothing view of the same observation.
    y = 0.5 * z + 0.25 * torch.roll(z, shifts=-1, dims=-1) + 0.25 * torch.roll(z, shifts=1, dims=-1)
    return _from_complex_iq(y, x_sat)


def _dc_remove_iq(x_sat: torch.Tensor) -> torch.Tensor:
    z = _to_complex_iq(x_sat)
    y = z - z.mean(dim=-1, keepdim=True)
    return _from_complex_iq(y, x_sat)


def _iq_channel_standardize(x_sat: torch.Tensor) -> torch.Tensor:
    if torch.is_complex(x_sat):
        z = x_sat
        y = z - z.mean(dim=-1, keepdim=True)
        rms = torch.sqrt(torch.mean(torch.abs(y) ** 2, dim=-1, keepdim=True).clamp_min(1e-8))
        return (y / rms).to(dtype=x_sat.dtype)
    y = x_sat.float() - x_sat.float().mean(dim=-1, keepdim=True)
    std = y.std(dim=-1, keepdim=True, unbiased=False).clamp_min(1e-6)
    return (y / std).to(dtype=x_sat.dtype)


def _highpass_residual_iq(x_sat: torch.Tensor) -> torch.Tensor:
    z = _to_complex_iq(x_sat)
    smooth = 0.5 * z + 0.25 * torch.roll(z, shifts=-1, dims=-1) + 0.25 * torch.roll(z, shifts=1, dims=-1)
    y = z - smooth
    return _from_complex_iq(_rms_normalize_iq(y), x_sat)


def _estimate_phase_step(z: torch.Tensor) -> torch.Tensor:
    if z.shape[-1] < 2:
        return torch.zeros((z.shape[0], 1), device=z.device, dtype=torch.float32)
    prod = z[:, 1:] * torch.conj(z[:, :-1])
    mean_prod = prod.mean(dim=-1, keepdim=True)
    return torch.angle(mean_prod).to(dtype=torch.float32)


def _blind_phase_correct_iq(x_sat: torch.Tensor, *, residual_delta: float = 0.0) -> torch.Tensor:
    z = _to_complex_iq(x_sat)
    steps = int(z.shape[-1])
    n = torch.arange(steps, device=z.device, dtype=torch.float32).view(1, -1)
    phase_step = _estimate_phase_step(z) + 2.0 * torch.pi * float(residual_delta)
    y = z * torch.exp(-1j * phase_step * n)
    return _from_complex_iq(y, x_sat)


def _local_power_smooth(z: torch.Tensor, *, radius: int = 4) -> torch.Tensor:
    power = torch.abs(z) ** 2
    acc = power
    count = 1
    for shift in range(1, int(radius) + 1):
        acc = acc + torch.roll(power, shifts=shift, dims=-1) + torch.roll(power, shifts=-shift, dims=-1)
        count += 2
    return acc / float(count)


def _amplitude_envelope_repair_iq(
    x_sat: torch.Tensor,
    *,
    radius: int = 4,
    strength: float = 0.5,
    gain_floor: float = 0.55,
    gain_ceil: float = 1.80,
) -> torch.Tensor:
    z = _to_complex_iq(x_sat)
    local_rms = torch.sqrt(_local_power_smooth(z, radius=int(radius)).clamp_min(1e-8))
    global_rms = torch.sqrt(torch.mean(torch.abs(z) ** 2, dim=-1, keepdim=True).clamp_min(1e-8))
    gain = torch.pow(global_rms / local_rms, float(strength)).clamp(float(gain_floor), float(gain_ceil))
    y = z * gain
    return _from_complex_iq(_rms_normalize_iq(y), x_sat)


def _spectral_soft_denoise_iq(x_sat: torch.Tensor, *, noise_q: float = 0.20, floor: float = 0.15) -> torch.Tensor:
    z = _to_complex_iq(x_sat)
    spec = torch.fft.fft(z, dim=-1)
    power = torch.abs(spec) ** 2
    noise = torch.quantile(power, float(noise_q), dim=-1, keepdim=True).clamp_min(1e-8)
    shrink = (power / (power + noise)).clamp_min(float(floor)).clamp_max(1.0)
    y = torch.fft.ifft(spec * shrink, dim=-1)
    return _from_complex_iq(_rms_normalize_iq(y), x_sat)


def _leo_repair_canonical_iq(x_sat: torch.Tensor, *, residual_delta: float = 0.0) -> torch.Tensor:
    repaired = _blind_phase_correct_iq(_dc_remove_iq(x_sat), residual_delta=float(residual_delta))
    return _rms_normalize_iq(repaired, clip_sigma=2.2)


def _satellite_tta_views(x_sat: torch.Tensor, policy: str) -> list[tuple[str, torch.Tensor]]:
    mode = str(policy or "none").strip().lower()
    if mode in {"", "none", "off", "0"}:
        return [("single", x_sat)]
    if mode not in set(SATELLITE_TTA_POLICIES) - {"none"}:
        raise ValueError(f"unknown satellite_tta_policy={policy!r}")
    z = _to_complex_iq(x_sat)
    steps = int(z.shape[-1])
    n = torch.arange(steps, device=z.device, dtype=torch.float32).view(1, -1)

    def cfo_view(delta: float) -> torch.Tensor:
        phase = 2.0 * torch.pi * float(delta) * n
        return _from_complex_iq(z * torch.exp(1j * phase), x_sat)

    if mode == "repair_canonical1":
        return [("repair_canonical", _leo_repair_canonical_iq(x_sat))]

    if mode == "rx_shift3":
        return [
            ("rx_base", x_sat),
            ("rx_shift_m2", torch.roll(x_sat, shifts=-2, dims=-1)),
            ("rx_shift_p2", torch.roll(x_sat, shifts=2, dims=-1)),
        ]
    if mode == "rx_cfo3":
        return [
            ("rx_base", x_sat),
            ("rx_cfo_m1e4", cfo_view(-1.0e-4)),
            ("rx_cfo_p1e4", cfo_view(1.0e-4)),
        ]
    if mode == "rx_light5":
        return [
            ("rx_base", x_sat),
            ("rx_shift_m2", torch.roll(x_sat, shifts=-2, dims=-1)),
            ("rx_shift_p2", torch.roll(x_sat, shifts=2, dims=-1)),
            ("rx_cfo_m1e4", cfo_view(-1.0e-4)),
            ("rx_cfo_p1e4", cfo_view(1.0e-4)),
        ]

    def phase_view(theta: float) -> torch.Tensor:
        phase = torch.tensor(float(theta), device=z.device, dtype=torch.float32)
        return _from_complex_iq(z * torch.exp(1j * phase), x_sat)

    if mode == "sat_rx_phys11":
        return [
            ("rx_base", x_sat),
            ("rx_cfo_m2e4", cfo_view(-2.0e-4)),
            ("rx_cfo_m1e4", cfo_view(-1.0e-4)),
            ("rx_cfo_p1e4", cfo_view(1.0e-4)),
            ("rx_cfo_p2e4", cfo_view(2.0e-4)),
            ("rx_shift_m1", torch.roll(x_sat, shifts=-1, dims=-1)),
            ("rx_shift_p1", torch.roll(x_sat, shifts=1, dims=-1)),
            ("rx_phase_m15deg", phase_view(-torch.pi / 12.0)),
            ("rx_phase_p15deg", phase_view(torch.pi / 12.0)),
            ("rx_agc_clip2p5", _rms_normalize_iq(x_sat, clip_sigma=2.5)),
            ("rx_short_fir", _short_fir_smooth_iq(x_sat)),
        ]

    if mode == "sat_rx_repair9":
        canonical = _leo_repair_canonical_iq(x_sat)
        amp = _amplitude_envelope_repair_iq(canonical, radius=4, strength=0.55)
        denoise = _spectral_soft_denoise_iq(canonical, noise_q=0.20, floor=0.18)
        fir = _rms_normalize_iq(_short_fir_smooth_iq(canonical), clip_sigma=2.2)
        return [
            ("repair_canonical", canonical),
            ("repair_amp_flat", amp),
            ("repair_spectral", denoise),
            ("repair_amp_spectral", _spectral_soft_denoise_iq(amp, noise_q=0.20, floor=0.18)),
            ("repair_short_fir", fir),
            ("repair_fir_amp", _amplitude_envelope_repair_iq(fir, radius=4, strength=0.45)),
            ("repair_cfo_m1e4", _leo_repair_canonical_iq(x_sat, residual_delta=-1.0e-4)),
            ("repair_cfo_p1e4", _leo_repair_canonical_iq(x_sat, residual_delta=1.0e-4)),
            ("repair_iq_standard", _iq_channel_standardize(canonical)),
        ]

    if mode == "sat_rx_repair_anchor7":
        dc = _dc_remove_iq(x_sat)
        base_rms = _rms_normalize_iq(x_sat, clip_sigma=2.8)
        canonical = _leo_repair_canonical_iq(x_sat)
        return [
            ("anchor_base", x_sat),
            ("anchor_dc", dc),
            ("anchor_rms", base_rms),
            ("repair_canonical", canonical),
            ("repair_cfo_m1e4", _leo_repair_canonical_iq(x_sat, residual_delta=-1.0e-4)),
            ("repair_cfo_p1e4", _leo_repair_canonical_iq(x_sat, residual_delta=1.0e-4)),
            ("repair_spectral_light", _spectral_soft_denoise_iq(canonical, noise_q=0.10, floor=0.35)),
        ]

    blind = _blind_phase_correct_iq(x_sat)
    blind_dc = _dc_remove_iq(blind)
    blind_agc = _rms_normalize_iq(blind, clip_sigma=2.0)
    return [
        ("rx_base", x_sat),
        ("rx_dc_remove", _dc_remove_iq(x_sat)),
        ("rx_iq_standard", _iq_channel_standardize(x_sat)),
        ("rx_blind_phase", blind),
        ("rx_blind_phase_dc", blind_dc),
        ("rx_blind_phase_agc2", blind_agc),
        ("rx_blind_m2e4", _blind_phase_correct_iq(x_sat, residual_delta=-2.0e-4)),
        ("rx_blind_m1e4", _blind_phase_correct_iq(x_sat, residual_delta=-1.0e-4)),
        ("rx_blind_p1e4", _blind_phase_correct_iq(x_sat, residual_delta=1.0e-4)),
        ("rx_blind_p2e4", _blind_phase_correct_iq(x_sat, residual_delta=2.0e-4)),
        ("rx_blind_shift_m1", torch.roll(blind, shifts=-1, dims=-1)),
        ("rx_blind_shift_p1", torch.roll(blind, shifts=1, dims=-1)),
        ("rx_blind_short_fir", _short_fir_smooth_iq(blind)),
        ("rx_highpass", _highpass_residual_iq(x_sat)),
        ("rx_blind_highpass", _highpass_residual_iq(blind)),
    ]


def _satellite_tta_view_count(policy: str) -> int:
    mode = str(policy or "none").strip().lower()
    if mode in {"", "none", "off", "0", "repair_canonical1"}:
        return 1
    if mode in {"rx_shift3", "rx_cfo3"}:
        return 3
    if mode == "rx_light5":
        return 5
    if mode == "sat_rx_phys11":
        return 11
    if mode == "sat_rx_blind15":
        return 15
    if mode == "sat_rx_repair9":
        return 9
    if mode == "sat_rx_repair_anchor7":
        return 7
    raise ValueError(f"unknown satellite_tta_policy={policy!r}")


@torch.no_grad()
def extract_features_with_metadata(
    model,
    loader,
    *,
    device: torch.device,
    feature_name: str,
    role: str,
    channel_view: str = "clean",
    sat_scenarios: Sequence[str] | None = None,
    sat_args: argparse.Namespace | None = None,
    sat_seed: int = 0,
    satellite_tta_policy: str = "none",
    aux_fft_logmag_dim: int = 0,
    aux_rf_stat_dim: int = 0,
    include_raw_iq: bool = False,
):
    feature_buf: list[np.ndarray] = []
    aux_fft_buf: list[np.ndarray] = []
    aux_rf_buf: list[np.ndarray] = []
    tx_logit_buf: list[np.ndarray] = []
    tx_buf: list[str] = []
    rx_buf: list[str] = []
    day_buf: list[str] = []
    eq_buf: list[str] = []
    sig_buf: list[str] = []
    role_buf: list[str] = []
    channel_view_buf: list[str] = []
    sat_scenario_buf: list[str] = []
    label_buf: list[int] = []
    domain_buf: list[int] = []
    raw_iq_buf: list[np.ndarray] = []
    model.eval()
    view = str(channel_view or "clean").lower()
    scenarios = list(sat_scenarios or [])
    sat_gen = make_torch_generator(device, int(sat_seed)) if view == "satellite" else None
    if view == "satellite" and not scenarios:
        raise ValueError(f"satellite feature export requires at least one scenario for role={role}")
    for bi, batch in enumerate(loader):
        if len(batch) == 4:
            x, y, d, meta = batch
        else:
            raise ValueError("WiSig feature export expects batches shaped (x, y, d, meta)")
        x = x.to(device, non_blocking=True)
        scenario = ""
        if view == "satellite":
            scenario = str(scenarios[int(bi) % len(scenarios)])
            if sat_args is None:
                raise ValueError("sat_args is required for satellite feature export")
            x, _ = apply_sat_channel_for_scenario(x, scenario, sat_args, gen=sat_gen, return_meta=False)
        n = int(x.shape[0])
        meta_tx = _meta_to_list(meta, "tx", n)
        meta_rx = _meta_to_list(meta, "rx", n)
        meta_day = _meta_to_list(meta, "day", n)
        meta_eq = _meta_to_list(meta, "equalized", n)
        meta_sig = _meta_to_list(meta, "sig_i", n)
        tta_views = _satellite_tta_views(x, satellite_tta_policy if view == "satellite" else "none")
        for tta_name, x_view in tta_views:
            if bool(include_raw_iq):
                raw_iq_buf.append(x_view.detach().cpu().float().numpy())
            if int(aux_fft_logmag_dim) > 0:
                aux_fft_buf.append(
                    _spectral_logmag_sketch_batch(
                        x_view.detach().cpu().float().numpy(),
                        dim=int(aux_fft_logmag_dim),
                    )
                )
            if int(aux_rf_stat_dim) > 0:
                if int(aux_rf_stat_dim) != 32:
                    raise ValueError("aux_rf_stat_dim currently supports only 0 or 32")
                aux_rf_buf.append(_rf_statistics_batch(x_view.detach().cpu().float().numpy()))
            identity_only = identity_only_feature_forward(model, x_view, feature_name)
            if identity_only is not None:
                z_tensor, logits_tensor = identity_only
            else:
                out = model(x_view, y_tx=None, grl_lambda=1.0, return_aux=True)
                feats = collect_feature_dict(out)
                if feature_name not in feats:
                    raise KeyError(
                        f"feature {feature_name!r} not found; available={sorted(feats.keys())}"
                    )
                z_tensor = feats[feature_name].float()
                logits_obj = out.get("tx_logits", out.get("logits")) if isinstance(out, dict) else None
                if logits_obj is None:
                    raise KeyError(
                        "model output does not include tx_logits/logits for Phase1 classifier audit"
                    )
                logits_tensor = logits_obj.float()
            z = z_tensor.detach().cpu().numpy()
            tx_logits = logits_tensor.detach().cpu().numpy()
            feature_buf.append(z)
            tx_logit_buf.append(tx_logits)
            label_buf.extend([int(v) for v in y.detach().cpu().reshape(-1).tolist()])
            domain_buf.extend([int(v) for v in d.detach().cpu().reshape(-1).tolist()])
            tx_buf.extend(meta_tx)
            rx_buf.extend(meta_rx)
            day_buf.extend(meta_day)
            eq_buf.extend(meta_eq)
            sig_buf.extend(meta_sig)
            role_buf.extend([role] * n)
            channel_view_buf.extend([tta_name if view == "satellite" else view] * n)
            sat_scenario_buf.extend([scenario] * n)
    if not feature_buf:
        raise ValueError(f"dataset role={role} produced no features")
    payload = {
        "features": np.concatenate(feature_buf, axis=0).astype(np.float32),
        "tx_logits": np.concatenate(tx_logit_buf, axis=0).astype(np.float32),
        "raw_labels": np.asarray(label_buf, dtype=np.int64),
        "domain_labels": np.asarray(domain_buf, dtype=np.int64),
        "tx_ids": np.asarray(tx_buf),
        "rx_ids": np.asarray(rx_buf),
        "day_ids": np.asarray(day_buf),
        "eq_ids": np.asarray(eq_buf),
        "sig_ids": np.asarray(sig_buf),
        "dataset_role": np.asarray(role_buf),
        "channel_views": np.asarray(channel_view_buf),
        "sat_scenarios": np.asarray(sat_scenario_buf),
    }
    if int(aux_fft_logmag_dim) > 0:
        payload["fft_logmag_features"] = np.concatenate(aux_fft_buf, axis=0).astype(np.float32)
    if bool(include_raw_iq):
        payload["raw_iq"] = np.concatenate(raw_iq_buf, axis=0).astype(np.float32)
    if int(aux_rf_stat_dim) > 0:
        payload["rf_stat_features"] = np.concatenate(aux_rf_buf, axis=0).astype(np.float32)
    if int(aux_fft_logmag_dim) > 0 and int(aux_rf_stat_dim) > 0:
        payload["fft_rf_features"] = np.concatenate(
            [payload["fft_logmag_features"], payload["rf_stat_features"]], axis=1
        ).astype(np.float32)
    return payload


def _concat_payloads(payloads: Sequence[dict[str, np.ndarray]]) -> dict[str, np.ndarray]:
    keys = list(payloads[0].keys())
    return {key: np.concatenate([p[key] for p in payloads], axis=0) for key in keys}


def _write_synthetic(out_npz: Path) -> None:
    features = []
    tx_ids = []
    for tx, base in {
        "old_a": [1.0, 0.0],
        "old_b": [0.0, 1.0],
        "new_c": [-1.0, 0.0],
        "unknown_d": [0.0, -1.0],
    }.items():
        for i in range(80):
            features.append([base[0] + 0.001 * i, base[1] - 0.001 * i])
            tx_ids.append(tx)
    out_npz.parent.mkdir(parents=True, exist_ok=True)
    np.savez(
        out_npz,
        features=np.asarray(features, dtype=np.float32),
        tx_ids=np.asarray(tx_ids),
        dataset_role=np.asarray(["synthetic"] * len(tx_ids)),
        manifest_json=json.dumps({"payload_source": "dry_run_synthetic_export"}, ensure_ascii=True),
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ckpt", type=Path, default=None)
    parser.add_argument("--wisig_pkl", type=str, default="./Dataset_WigSig/ManySig.pkl")
    parser.add_argument("--new_wisig_pkl", type=str, default=None)
    parser.add_argument("--out_npz", type=Path, required=True)
    parser.add_argument("--feature_name", default="z_id")
    parser.add_argument(
        "--aux_fft_logmag_dim",
        type=int,
        default=0,
        help="Also export same-view FFT log-magnitude descriptors; 0 disables the auxiliary feature.",
    )
    parser.add_argument(
        "--aux_rf_stat_dim",
        type=int,
        choices=(0, 32),
        default=0,
        help="Also export a same-view 32-D gain-normalized IQ statistics descriptor.",
    )
    parser.add_argument(
        "--include_raw_iq",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Persist the exact post-channel IQ view for support-only front-end adaptation.",
    )
    parser.add_argument("--dataset", default="wisig")
    parser.add_argument("--num_classes", type=int, default=None)
    parser.add_argument("--model_size", default=None)
    parser.add_argument("--model_variant", default=None)
    parser.add_argument("--branch_ablation", default=None)
    parser.add_argument("--sample_rate_hz", type=float, default=None)
    parser.add_argument("--source_tx_ids", required=False)
    parser.add_argument("--target_old_tx_ids", default=None)
    parser.add_argument("--new_tx_ids", required=False)
    parser.add_argument("--unknown_tx_ids", default=None)
    parser.add_argument("--proxy_unknown_tx_ids", default=None)
    parser.add_argument("--wisig_equalized", default="1")
    parser.add_argument("--wisig_domain", default="rx_day")
    parser.add_argument("--wisig_out_len", type=int, default=256)
    parser.add_argument("--source_days", default=None)
    parser.add_argument("--source_rxs", default=None)
    parser.add_argument("--target_old_days", default=None)
    parser.add_argument("--target_old_rxs", default=None)
    parser.add_argument("--new_days", default=None)
    parser.add_argument("--new_rxs", default=None)
    parser.add_argument("--proxy_unknown_days", default=None)
    parser.add_argument("--proxy_unknown_rxs", default=None)
    parser.add_argument("--max_samples_per_combo", type=int, default=0)
    parser.add_argument("--max_samples_per_tx", type=int, default=400)
    parser.add_argument("--batch_size", type=int, default=512)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--seed", type=int, default=1337)
    parser.add_argument("--source_channel_view", default="clean", choices=["clean", "satellite"])
    parser.add_argument("--source_sat_scenarios", default=None)
    parser.add_argument("--source_sat_seed", type=int, default=None)
    parser.add_argument("--target_new_channel_view", default="clean", choices=["clean", "satellite"])
    parser.add_argument("--target_new_sat_scenarios", default="clear_leo,low_elev_leo,rain_leo,storm_mp,mixed_orbit")
    parser.add_argument("--target_new_sat_seed", type=int, default=None)
    parser.add_argument("--target_old_channel_view", default=None, choices=["clean", "satellite"])
    parser.add_argument("--target_old_sat_scenarios", default=None)
    parser.add_argument("--target_old_sat_seed", type=int, default=None)
    parser.add_argument("--proxy_unknown_channel_view", default="clean", choices=["clean", "satellite"])
    parser.add_argument("--proxy_unknown_sat_scenarios", default=None)
    parser.add_argument("--proxy_unknown_sat_seed", type=int, default=None)
    parser.add_argument(
        "--satellite_tta_policy",
        default="none",
        choices=SATELLITE_TTA_POLICIES,
        help="Receive-side repair/TTA views generated after one satellite channel observation; default keeps one view.",
    )
    parser.add_argument(
        "--star_ground_channel_impl",
        default="legacy_satellite",
        choices=["legacy_satellite", "simplified_leo_residual"],
        help="Audit/control field for the star-ground channel implementation used by satellite views.",
    )
    parser.add_argument("--sat_fs_hz", type=float, default=25e6)
    parser.add_argument("--sat_fc_hz", type=float, default=2.462e9)
    parser.add_argument("--dry_run_synthetic", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.dry_run_synthetic:
        _write_synthetic(args.out_npz)
        print(json.dumps({"out_npz": str(args.out_npz), "mode": "dry_run_synthetic"}, ensure_ascii=False))
        return 0
    if args.ckpt is None:
        raise ValueError("--ckpt is required unless --dry_run_synthetic is set")
    if not args.source_tx_ids:
        raise ValueError("--source_tx_ids is required for real WiSig export")
    requested_new_tx_ids = parse_tx_id_list(args.new_tx_ids)
    old_unknown_only = not requested_new_tx_ids
    if old_unknown_only and not parse_tx_id_list(args.target_old_tx_ids):
        raise ValueError("--target_old_tx_ids is required when --new_tx_ids is omitted")

    source_ds, source_info = _build_wisig_dataset(
        pkl_path=str(args.wisig_pkl),
        tx_spec=str(args.source_tx_ids),
        role="source",
        equalized=str(args.wisig_equalized),
        out_len=int(args.wisig_out_len),
        domain=str(args.wisig_domain),
        days=args.source_days,
        rxs=args.source_rxs,
        max_samples_per_combo=int(args.max_samples_per_combo),
        max_samples_per_tx=int(args.max_samples_per_tx),
        seed=int(args.seed),
    )
    new_pkl_path = str(args.new_wisig_pkl or args.wisig_pkl)
    new_raw = load_wisig_compact_pkl(new_pkl_path)
    resolved_new_labels: list[str] = []
    if requested_new_tx_ids:
        _, resolved_new_labels = _resolve_tx_indices(new_raw.get("tx_list", []), args.new_tx_ids, field="new_tx_ids")
    resolved_unknown_labels: list[str] = []
    if parse_tx_id_list(args.unknown_tx_ids):
        _, resolved_unknown_labels = _resolve_tx_indices(
            new_raw.get("tx_list", []),
            args.unknown_tx_ids,
            field="unknown_tx_ids",
        )
    resolved_proxy_unknown_labels: list[str] = []
    if parse_tx_id_list(args.proxy_unknown_tx_ids):
        _, resolved_proxy_unknown_labels = _resolve_tx_indices(
            new_raw.get("tx_list", []),
            args.proxy_unknown_tx_ids,
            field="proxy_unknown_tx_ids",
        )
    overlap_audit = assert_disjoint_tx_sets(
        source_tx_ids=source_info["tx_labels"],
        new_tx_ids=resolved_new_labels,
        unknown_tx_ids=resolved_unknown_labels,
    )
    proxy_overlap_audit = {
        "proxy_unknown_overlaps_source": sorted(set(resolved_proxy_unknown_labels).intersection(source_info["tx_labels"])),
        "proxy_unknown_overlaps_target_unknown": sorted(
            set(resolved_proxy_unknown_labels).intersection(resolved_unknown_labels)
        ),
        "proxy_unknown_overlaps_target_new": sorted(set(resolved_proxy_unknown_labels).intersection(resolved_new_labels)),
    }
    if proxy_overlap_audit["proxy_unknown_overlaps_source"]:
        raise ValueError(f"proxy_unknown_tx_ids overlap source_tx_ids: {proxy_overlap_audit}")
    new_ds = None
    new_info = None
    if resolved_new_labels:
        new_ds, new_info = _build_wisig_dataset(
            pkl_path=new_pkl_path,
            tx_spec=",".join(resolved_new_labels),
            role="target_new",
            equalized=str(args.wisig_equalized),
            out_len=int(args.wisig_out_len),
            domain=str(args.wisig_domain),
            days=args.new_days,
            rxs=args.new_rxs,
            max_samples_per_combo=int(args.max_samples_per_combo),
            max_samples_per_tx=int(args.max_samples_per_tx),
            seed=int(args.seed) + 17,
        )
    unknown_ds = None
    unknown_info = None
    if resolved_unknown_labels:
        unknown_days = args.new_days
        unknown_rxs = args.new_rxs
        if old_unknown_only:
            unknown_days = args.target_old_days or args.new_days
            unknown_rxs = args.target_old_rxs or args.new_rxs
        unknown_ds, unknown_info = _build_wisig_dataset(
            pkl_path=new_pkl_path,
            tx_spec=",".join(resolved_unknown_labels),
            role="target_unknown",
            equalized=str(args.wisig_equalized),
            out_len=int(args.wisig_out_len),
            domain=str(args.wisig_domain),
            days=unknown_days,
            rxs=unknown_rxs,
            max_samples_per_combo=int(args.max_samples_per_combo),
            max_samples_per_tx=int(args.max_samples_per_tx),
            seed=int(args.seed) + 31,
        )
    proxy_unknown_ds = None
    proxy_unknown_info = None
    if resolved_proxy_unknown_labels:
        proxy_unknown_ds, proxy_unknown_info = _build_wisig_dataset(
            pkl_path=new_pkl_path,
            tx_spec=",".join(resolved_proxy_unknown_labels),
            role="proxy_unknown",
            equalized=str(args.wisig_equalized),
            out_len=int(args.wisig_out_len),
            domain=str(args.wisig_domain),
            days=args.proxy_unknown_days or args.new_days,
            rxs=args.proxy_unknown_rxs or args.source_rxs,
            max_samples_per_combo=int(args.max_samples_per_combo),
            max_samples_per_tx=int(args.max_samples_per_tx),
            seed=int(args.seed) + 43,
        )

    ckpt = torch.load(args.ckpt, map_location="cpu")
    if "args" not in ckpt or "model" not in ckpt:
        raise KeyError("checkpoint must contain 'args' and 'model'")
    device = torch.device(str(args.device) if torch.cuda.is_available() else "cpu")
    model, checkpoint_load_audit = build_exact_ssdg_model_from_checkpoint(
        ckpt,
        input_len=int(args.wisig_out_len),
        device=device,
    )
    missing: list[str] = []
    unexpected: list[str] = []
    skipped_mismatch: list[str] = []

    source_loader = DataLoader(source_ds, batch_size=int(args.batch_size), shuffle=False, num_workers=0, drop_last=False)
    new_loader = (
        DataLoader(new_ds, batch_size=int(args.batch_size), shuffle=False, num_workers=0, drop_last=False)
        if new_ds is not None
        else None
    )
    star_ground_impl = str(args.star_ground_channel_impl)
    source_view = str(args.source_channel_view).lower()
    source_scenarios = (
        parse_sat_scenarios(str(args.source_sat_scenarios))
        if source_view == "satellite"
        else []
    )
    _validate_star_ground_impl(star_ground_impl, source_scenarios, field="source_sat_scenarios")
    source_seed = int(args.source_sat_seed if args.source_sat_seed is not None else int(args.seed) + 613)
    target_new_view = str(args.target_new_channel_view).lower()
    target_new_scenarios = parse_sat_scenarios(str(args.target_new_sat_scenarios)) if target_new_view == "satellite" else []
    if not old_unknown_only:
        _validate_star_ground_impl(star_ground_impl, target_new_scenarios, field="target_new_sat_scenarios")
    source_payload = extract_features_with_metadata(
        model,
        source_loader,
        device=device,
        feature_name=str(args.feature_name),
        role="source",
        channel_view=source_view,
        sat_scenarios=source_scenarios,
        sat_args=args,
        sat_seed=source_seed,
        satellite_tta_policy=str(args.satellite_tta_policy),
        aux_fft_logmag_dim=int(args.aux_fft_logmag_dim),
        aux_rf_stat_dim=int(args.aux_rf_stat_dim),
        include_raw_iq=bool(args.include_raw_iq),
    )
    source_channel_profile = {
        "view": source_view,
        "applied_roles": ["source"] if source_view == "satellite" else [],
        "downstream_roles": ["source_old_proxy_head_training"],
        "scenarios": source_scenarios,
        "scenario_configs": {name: sat_channel_config_for_scenario(name) for name in source_scenarios},
        "star_ground_channel_impl": star_ground_impl,
        "sat_seed": source_seed,
        "fs_hz": float(args.sat_fs_hz),
        "fc_hz": float(args.sat_fc_hz),
    }
    proxy_unknown_payload = None
    proxy_unknown_channel_profile = None
    if proxy_unknown_ds is not None:
        proxy_unknown_view = str(args.proxy_unknown_channel_view).lower()
        proxy_unknown_scenarios = (
            parse_sat_scenarios(str(args.proxy_unknown_sat_scenarios))
            if proxy_unknown_view == "satellite"
            else []
        )
        _validate_star_ground_impl(star_ground_impl, proxy_unknown_scenarios, field="proxy_unknown_sat_scenarios")
        proxy_unknown_seed = int(
            args.proxy_unknown_sat_seed if args.proxy_unknown_sat_seed is not None else int(args.seed) + 719
        )
        proxy_unknown_payload = extract_features_with_metadata(
            model,
            DataLoader(
                proxy_unknown_ds,
                batch_size=int(args.batch_size),
                shuffle=False,
                num_workers=0,
                drop_last=False,
            ),
            device=device,
            feature_name=str(args.feature_name),
            role="proxy_unknown",
            channel_view=proxy_unknown_view,
            sat_scenarios=proxy_unknown_scenarios,
            sat_args=args,
            sat_seed=proxy_unknown_seed,
            satellite_tta_policy=str(args.satellite_tta_policy),
            aux_fft_logmag_dim=int(args.aux_fft_logmag_dim),
            aux_rf_stat_dim=int(args.aux_rf_stat_dim),
            include_raw_iq=bool(args.include_raw_iq),
        )
        proxy_unknown_channel_profile = {
            "view": proxy_unknown_view,
            "applied_roles": ["proxy_unknown"] if proxy_unknown_view == "satellite" else [],
            "downstream_roles": ["source_proxy_unknown_calibration"],
            "scenarios": proxy_unknown_scenarios,
            "scenario_configs": {name: sat_channel_config_for_scenario(name) for name in proxy_unknown_scenarios},
            "star_ground_channel_impl": star_ground_impl,
            "sat_seed": proxy_unknown_seed,
            "fs_hz": float(args.sat_fs_hz),
            "fc_hz": float(args.sat_fc_hz),
        }
    target_old_payload = None
    target_old_info = None
    target_old_channel_profile = None
    target_old_view = None
    target_old_scenarios: list[str] = []
    target_old_seed = None
    if parse_tx_id_list(args.target_old_tx_ids):
        target_old_ds, target_old_info = _build_wisig_dataset(
            pkl_path=str(args.wisig_pkl),
            tx_spec=str(args.target_old_tx_ids),
            role="target_old",
            equalized=str(args.wisig_equalized),
            out_len=int(args.wisig_out_len),
            domain=str(args.wisig_domain),
            days=args.target_old_days or args.new_days,
            rxs=args.target_old_rxs or args.new_rxs,
            max_samples_per_combo=int(args.max_samples_per_combo),
            max_samples_per_tx=int(args.max_samples_per_tx),
            seed=int(args.seed) + 29,
        )
        target_old_view = str(args.target_old_channel_view or args.target_new_channel_view).lower()
        target_old_scenarios = (
            parse_sat_scenarios(str(args.target_old_sat_scenarios or args.target_new_sat_scenarios))
            if target_old_view == "satellite"
            else []
        )
        _validate_star_ground_impl(star_ground_impl, target_old_scenarios, field="target_old_sat_scenarios")
        target_old_seed = int(args.target_old_sat_seed if args.target_old_sat_seed is not None else int(args.seed) + 811)
        target_old_payload = extract_features_with_metadata(
            model,
            DataLoader(target_old_ds, batch_size=int(args.batch_size), shuffle=False, num_workers=0, drop_last=False),
            device=device,
            feature_name=str(args.feature_name),
            role="target_old",
            channel_view=target_old_view,
            sat_scenarios=target_old_scenarios,
            sat_args=args,
            sat_seed=target_old_seed,
            satellite_tta_policy=str(args.satellite_tta_policy),
            aux_fft_logmag_dim=int(args.aux_fft_logmag_dim),
            aux_rf_stat_dim=int(args.aux_rf_stat_dim),
            include_raw_iq=bool(args.include_raw_iq),
        )
        target_old_channel_profile = {
            "view": target_old_view,
            "applied_roles": ["target_old"] if target_old_view == "satellite" else [],
            "downstream_roles": ["target_old_support", "target_old_query"] if target_old_view == "satellite" else [],
            "scenarios": target_old_scenarios,
            "scenario_configs": {name: sat_channel_config_for_scenario(name) for name in target_old_scenarios},
            "star_ground_channel_impl": star_ground_impl,
            "sat_seed": target_old_seed,
            "fs_hz": float(args.sat_fs_hz),
            "fc_hz": float(args.sat_fc_hz),
            "implementation": "cvsrffi.eval.apply_sat_channel_for_scenario -> sat_channel.apply_sat_gnd_channel_batch",
        }
    new_payload = None
    if new_loader is not None:
        new_payload = extract_features_with_metadata(
            model,
            new_loader,
            device=device,
            feature_name=str(args.feature_name),
            role="target_new",
            channel_view=target_new_view,
            sat_scenarios=target_new_scenarios,
            sat_args=args,
            sat_seed=int(args.target_new_sat_seed if args.target_new_sat_seed is not None else int(args.seed) + 911),
            satellite_tta_policy=str(args.satellite_tta_policy),
            aux_fft_logmag_dim=int(args.aux_fft_logmag_dim),
            aux_rf_stat_dim=int(args.aux_rf_stat_dim),
            include_raw_iq=bool(args.include_raw_iq),
        )
    unknown_payload = None
    target_unknown_view = target_new_view
    target_unknown_scenarios = target_new_scenarios
    target_unknown_seed = int(args.target_new_sat_seed if args.target_new_sat_seed is not None else int(args.seed) + 913)
    if old_unknown_only and target_old_view is not None:
        target_unknown_view = str(target_old_view)
        target_unknown_scenarios = list(target_old_scenarios)
        target_unknown_seed = int(args.target_old_sat_seed if args.target_old_sat_seed is not None else int(args.seed) + 913)
    if unknown_ds is not None:
        unknown_payload = extract_features_with_metadata(
            model,
            DataLoader(unknown_ds, batch_size=int(args.batch_size), shuffle=False, num_workers=0, drop_last=False),
            device=device,
            feature_name=str(args.feature_name),
            role="target_unknown",
            channel_view=target_unknown_view,
            sat_scenarios=target_unknown_scenarios,
            sat_args=args,
            sat_seed=target_unknown_seed,
            satellite_tta_policy=str(args.satellite_tta_policy),
            aux_fft_logmag_dim=int(args.aux_fft_logmag_dim),
            aux_rf_stat_dim=int(args.aux_rf_stat_dim),
            include_raw_iq=bool(args.include_raw_iq),
        )
    payload_parts = [source_payload]
    if proxy_unknown_payload is not None:
        payload_parts.append(proxy_unknown_payload)
    if target_old_payload is not None:
        payload_parts.append(target_old_payload)
    if new_payload is not None:
        payload_parts.append(new_payload)
    if unknown_payload is not None:
        payload_parts.append(unknown_payload)
    payload = _concat_payloads(payload_parts)
    target_new_channel_profile = None
    if not old_unknown_only:
        target_new_channel_profile = {
            "view": target_new_view,
            "applied_roles": ["target_new"] if target_new_view == "satellite" else [],
            "downstream_roles": ["new_support", "new_query"] if target_new_view == "satellite" else [],
            "scenarios": target_new_scenarios,
            "scenario_configs": {name: sat_channel_config_for_scenario(name) for name in target_new_scenarios},
            "star_ground_channel_impl": star_ground_impl,
            "sat_seed": int(args.target_new_sat_seed if args.target_new_sat_seed is not None else int(args.seed) + 911),
            "fs_hz": float(args.sat_fs_hz),
            "fc_hz": float(args.sat_fc_hz),
            "implementation": "cvsrffi.eval.apply_sat_channel_for_scenario -> sat_channel.apply_sat_gnd_channel_batch",
        }
    target_unknown_channel_profile = None
    if unknown_info is not None:
        target_unknown_channel_profile = {
            "view": target_unknown_view,
            "applied_roles": ["target_unknown"] if target_unknown_view == "satellite" else [],
            "downstream_roles": ["unknown_query"] if target_unknown_view == "satellite" else [],
            "scenarios": target_unknown_scenarios,
            "scenario_configs": {name: sat_channel_config_for_scenario(name) for name in target_unknown_scenarios},
            "star_ground_channel_impl": star_ground_impl,
            "sat_seed": target_unknown_seed,
            "fs_hz": float(args.sat_fs_hz),
            "fc_hz": float(args.sat_fc_hz),
            "implementation": "cvsrffi.eval.apply_sat_channel_for_scenario -> sat_channel.apply_sat_gnd_channel_batch",
        }
    manifest = {
        "feature_name": str(args.feature_name),
        "feature_key": str(args.feature_name),
        "checkpoint": str(args.ckpt),
        "source_checkpoint_sha256": _sha256_file(args.ckpt),
        "class_id_to_tx": list(source_info["tx_labels"]),
        "logit_class_order": list(range(len(source_info["tx_labels"]))),
        "classification_head_contract": "dual_cvsincnet_tx_logits_v1",
        "checkpoint_load_strict": True,
        "identity_only_forward": can_use_identity_only_forward(model, str(args.feature_name)),
        "domain_branch_executed_for_qknn": not can_use_identity_only_forward(
            model, str(args.feature_name)
        ),
        "checkpoint_load_audit": checkpoint_load_audit,
        "target_new_channel_view": "disabled" if old_unknown_only else target_new_view,
        "target_unknown_channel_view": target_unknown_view,
        "target_channel_view": "satellite/LEO" if target_unknown_view == "satellite" else "clean",
        "star_ground_channel_impl": star_ground_impl,
        "target_channel_scenarios": target_unknown_scenarios,
        "satellite_tta_policy": str(args.satellite_tta_policy),
        "satellite_tta_view_count": _satellite_tta_view_count(str(args.satellite_tta_policy)),
        "aux_fft_logmag_dim": int(args.aux_fft_logmag_dim),
        "raw_iq_included": bool(args.include_raw_iq),
        "raw_iq_contract": (
            "exact_post_channel_single_view_for_support_only_adaptation"
            if bool(args.include_raw_iq)
            else "not_persisted"
        ),
        "aux_fft_feature_key": "fft_logmag_features" if int(args.aux_fft_logmag_dim) > 0 else "",
        "aux_fft_view_alignment": "same_post_channel_view_as_backbone",
        "aux_rf_stat_dim": int(args.aux_rf_stat_dim),
        "aux_rf_feature_key": "rf_stat_features" if int(args.aux_rf_stat_dim) > 0 else "",
        "aux_fft_rf_feature_key": (
            "fft_rf_features"
            if int(args.aux_fft_logmag_dim) > 0 and int(args.aux_rf_stat_dim) > 0
            else ""
        ),
        "aux_rf_view_alignment": "same_post_channel_view_as_backbone",
        "deployment_primary_view": (
            "satellite/LEO target view" if target_unknown_view == "satellite" else "clean control/source reference"
        ),
        "source": source_info,
        "target_old": target_old_info,
        "target_new": new_info,
        "target_unknown": unknown_info,
        "proxy_unknown": proxy_unknown_info,
        "source_tx_ids": source_info["tx_labels"],
        "target_old_tx_ids": [] if target_old_info is None else target_old_info["tx_labels"],
        "new_tx_ids": resolved_new_labels,
        "unknown_tx_ids": resolved_unknown_labels,
        "proxy_unknown_tx_ids": resolved_proxy_unknown_labels,
        "requested_source_tx_ids": parse_tx_id_list(args.source_tx_ids),
        "requested_target_old_tx_ids": parse_tx_id_list(args.target_old_tx_ids),
        "requested_new_tx_ids": parse_tx_id_list(args.new_tx_ids),
        "requested_unknown_tx_ids": parse_tx_id_list(args.unknown_tx_ids),
        "requested_proxy_unknown_tx_ids": parse_tx_id_list(args.proxy_unknown_tx_ids),
        "overlap_audit": overlap_audit,
        "proxy_overlap_audit": proxy_overlap_audit,
        "channel_profile": {
            "source": source_channel_profile,
            "proxy_unknown": proxy_unknown_channel_profile,
            "target_old": target_old_channel_profile,
            "target_new": target_new_channel_profile,
            "target_unknown": target_unknown_channel_profile,
        },
        "missing_keys": len(missing),
        "unexpected_keys": len(unexpected),
        "skipped_mismatch": len(skipped_mismatch),
    }
    payload["manifest_json"] = np.asarray(json.dumps(manifest, ensure_ascii=True))
    args.out_npz.parent.mkdir(parents=True, exist_ok=True)
    np.savez(args.out_npz, **payload)
    print(json.dumps({"out_npz": str(args.out_npz), "manifest": manifest}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
