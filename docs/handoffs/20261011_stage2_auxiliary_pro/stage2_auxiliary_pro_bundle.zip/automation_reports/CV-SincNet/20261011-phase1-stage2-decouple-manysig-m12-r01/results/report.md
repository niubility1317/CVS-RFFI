# 固定纯 CE 父基线上的 40 轮多解耦实验

日期：2026-10-11。状态：**已授权实现，正在完成本地验证与发布准备；尚未确认远端启动，84% 未验证。**

run_id：`20261011-phase1-stage2-decouple-manysig-m12-r01`。group_id：`cvs-fixed-parent-stage2-multi-decouple`。逐行配置、路径和六类 seed 见 [experiment.json](experiment.json)，执行后的真实状态以同 run 的 `events.jsonl`、PID/GPU 读回及产物为准。

## 目的与完整矩阵

本轮复用第一次纯 CE 基线，在同一 seed 对应的固定父权重上独立开展第二阶段微调。用户已明确授权三种子、每个方案 40 个 epoch、每张卡最多 4 个实验进程，训练完成后自动测试 **clean**。本轮明确的 clean-only 指令覆盖此前 clean＋六种 practical 默认；不追加卫星测试。

| 方案 | 身份学习目标 | 三个 model seed | 作用 |
|---|---|---|---|
| C0 | 纯 CE | 2026092701、2026092702、2026092703 | 同预算续训对照 |
| C1 | CE＋父模型原正确样本的裕量保护 | 同上 | 分离保护项收益 |
| C2 | C1＋冻结 L/T 网络生成真实 IQ 动作 | 同上 | 分离动作与稳定性约束收益 |
| C3 | C2＋跨 TX 核验的 R 真实样本袋裕量修复 | 同上 | 固定主结果，共享采样下的 R 增量 |

共 12 行第二阶段训练，另复用 3 行 P0 父模型已有 clean prediction。C0 至 C3 同 seed 使用相同预定主样本序列；C2/C3 共享同一动作产物、动作随机码及 L/L/T/T 日程。所有变体独立加载同一父模型，不串接上次测试表现较好的变体。

主终点为 **C3 三 seed clean 准确率均值 ≥84%**，同时报告全部三个 seed、最小值、样本标准差、Macro-F1 和最差 RX。缺 seed 标为 partial。固定报告 `C3−P0`、`C3−C0`、`C0−P0` 的逐 seed 配对差；C0−P0 包含新增训练、采样、优化器及学习率的共同改变，不能单独归因为“额外 40 轮”。即使达到 84%，如果 C3−C0 没有增量，也不能将达标归功于多解耦。三种子正均值不自动等于统计显著。

## 父模型、数据与版本

父权重固定为远端 `runs/20261010-phase1-feature-disentangle-manysig-m48-r02/native-s<seed>/source/final_ssdg.pth`。其真实训练源为 r01，提交 `d4723b1aa227fce6368fd25680bb74b1190557d7`；r02 只恢复训练后诊断，未新增训练。每个父模型从零执行 E200、44,400 次身份更新，按最终轮次固定权重。运行前重新核对实际 checkpoint、配置及完整源角色。

继承的是当前身份网络中的频域/PA 门控、融合与参考响应结构，以及固定 scale=30 的 cosine 分类头。历史带伪标签 batch_neighbor 门控的 no-satellite 实验并非本轮纯 CE 父来源。严格加载父参数和缓冲区后才建立源缓存、L/T 与 R；本轮重置 AdamW 和学习率，不称为精确恢复原优化轨迹。

ManySig 输入保持 equalized=1、中心裁剪/补零至 256、逐包复数 RMS 归一化、25 MHz。源 RX 索引为 1/3/4/6/8，源日期为 1/2/3；L_s=6,300、U_s=56,700、V=27,000，继承相同物理 ID 角色。实际训练与辅助拟合只使用 L_s；U_s 只核对角色索引，不采样、不读取其标签、不保留训练迭代器。V 只做只读验证。

matched 配方的 split 记录为 392005；实际切分按 TX/RX/day/eq 与包序号确定，不使用新随机切分。每行分别记录 model、split、data、augmentation、support、evaluation 六类随机性。主采样与关系采样分别为 model+101、model+202；L/T 拟合为 model+17041、model+34082；动作码为 model+13×step，辅助 dropout 为 model+31×step；R 折初始化为 model+9137+fold。C0/C1 augmentation 为 N/A；support 为 N/A；clean 使用固定已有观测，evaluation 随机 seed 为 N/A。源压力诊断另固定 seed=2026101007。

本地实现前基点为 `9a7e184c37f5936e5a4cafc12175183a8a0e7b2a`，仅表示父代码版本，**不是本轮尚待提交的执行版本**。发布版本由 `release_commit.txt` 固定并在运行登记和 resolved config 写回。

## 固定训练配方与实际约束

每行 40 个 epoch，每 epoch 222 次身份更新，共 8,880 次；含父训练的累计身份更新为 53,280 次。新的 AdamW 使用 weight decay=1e-4；编码器峰值 LR=3e-5，融合/分类头峰值 LR=1e-4，前 444 步 warmup，随后 cosine 衰减至 1e-6。最终 E40 冻结，不按目标成绩选轮次。

`L = CE + min(step/444,1) × [0.1 L_keep + I4(0.25 L_aug + 0.1 L_drop) + I8 0.1 L_R]`。

CE label smoothing=0；辅助项采用单向 Huber，delta_keep=delta_L=delta_T=0.5 logit 单位。系数固定，不根据成熟 CE 的梯度比例或倒数调权。无半监督、伪标签、EMA 教师、星地信道增强、GRL、正交、互信息、Fishr 或 MixStyle。

每 seed 只建立一次 L_s 父裕量/正确性/物理状态缓存。L/T 为两个独立小网络，各 4,980 参数，输入仅为 40 维物理状态与 8 维随机动作码。严格冻结父模型，各执行两次完整 L_s 遍历，最大化真实 IQ 的父裕量下降；准备完成后动作网络冻结，身份训练不持续调用父模型。每 4 次身份更新处理最多 32 个 L_s 样本，L/L/T/T 循环，不增加联合 L+T。

L 沿用 delay 1/3 的短复数 FIR，每个抽头实/虚分量限幅 0.06。T 保留常量相位 ±0.25 rad、CFO ±3,120 Hz、平滑相位噪声强度上限 0.025 rad，curvature=0；按设计补入独立的 **±0.25 sample 分数延迟**。该微小时序边界是本轮固定工程参数，不声称已由源数据校准，也不是卫星模拟。两侧各补 256 个零，768 点 FFT 相移，再截取原中心 256 点；零延迟严格恒等并保留延迟梯度。截窗外 IQ 取零，边缘可能有 sinc 振铃，不能宣称知道未观测包外波形。新增检查覆盖正负延迟、内部常量/复指数、零变换、边界和有限差分梯度。

R 用固定三个双 TX 留出折，在另四个 TX 上拟合物理状态到条件裕量残差，输入不含身份 embedding、TX 标签、RX ID 或当前学生 loss。条件为同 TX/day/质量区间；每组至少 8 个不同物理 ID，质量区间按 4→2→1 的既定合并规则处理。留出 TX 的跨 RX 均值差决定冻结可靠度，无有效统计时 c=0，不设正下限。三折分别拟合 200 步，AdamW LR=.002、weight decay=0。

每 8 次身份更新在主 batch128 中预留 32 个位置，按 2TX×2RX×8 个不同物理样本构造两条关系；其余 96 个样本按公共序列取样。关系抽样本身不依据 R 的预测困难度，所有组别均使用该日程。C3 复用主前向，把强袋裕量停止梯度后作为带上限的参照，弱袋梯度直接进入身份编码器；失效关系贡献零，按原计划关系数量归约，可靠度只乘一次。

## 诊断、成本与自动测试

保留详细实际参数、逐步压缩 JSONL、紧凑 epoch JSONL/CSV 及文本日志。报告损失及权重、学习率、真实动作次数/裕量下降、不同物理 ID 数、R 留出误差/方向准确率/c、弱袋提升与强袋下降、父模型原正确样本的保护轨迹。每 888 步记录 CE、未加权和加权辅助项到编码器及头部的梯度绝对范数；CE 范数接近零时比值记 N/A。梯度路径和执行次数不是性能收益的替代证据。

成本分为父 E200、每 seed 一次共享准备、每行 E40、源诊断和目标测试。记录硬件、实际共享 GPU 墙钟时间、峰值显存、训练参数及累计预算；不把已发生父训练隐藏，也不根据 40/200 宣称固定加速倍数。最终推理只用身份网络。

每行最终 E40 及源诊断完成后立即自动进入 clean 预测，再由独立 CPU scorer 连接 truth；不等待其他行完成。clean 每行 168,000 个相同物理 query、6 个注册类、7 个目标 RX、4 个日期，逐样本同时面对全部六类。复用 P0 已有 prediction 前检查对应 checkpoint、seed 和物理 ID。所有结果与负结果保留，不回流选模、调参、停止或选择性重跑。

唯一 owner 为 `codex/root/stage2-decouple-20261011`。调度按每卡最多 4 个实验进程计算已有占用，使用剩余容量，不抢占或修改健康任务。技术失败保留产物、记录 FAILED，不自动重试。

代码及配置见 `experiments/cvs_stage2_decouple/`；独占远端输出为 `/home/szu2070436088/2510044040/CV-SincNet/runs/20261011-phase1-stage2-decouple-manysig-m12-r01/`。本地登记归档为 `automation_reports/CV-SincNet/20261011-phase1-stage2-decouple-manysig-m12-r01/`。发布与运行状态须由提交、PID/GPU、日志增长、resolved config 和最终 prediction/score 的独立读回证明。

## 来源与当前证据边界

设计依据为 `docs/CVS_MULTI_DISENTANGLE_STAGE2_20261011.md` 的完整源端审计：此前 R 缺少编码器梯度且可靠度很低，L/T 真实 IQ 约束较有依据；相关历史运行保留 r01/r02 原始记录。本轮没有根据目标成绩选择父模型或参数。

本地动作 CPU/CUDA 与源缓存检查已经通过；全包集成、独立 P0/P1 审查和发布证据由 launch owner 汇总。本报告登记的是已授权的固定方案，**目前不宣称远端已启动、实验已完成或 84% 已达成**。


# Fixed-parent 40-epoch multi-disentanglement: clean test

Each row uses 168000 fixed physical queries across 7 receivers and 4 days. Predictions precede independent truth access.
P0 predictions are reused when registered. Results do not feed model, hyperparameter, or rerun selection.

| Arm | Seeds | Mean accuracy (%) | SD (pp) | Minimum (%) | Macro-F1 (%) |
|---|---:|---:|---:|---:|---:|
| P0 | 3 | 80.526 | 1.320 | 79.052 | 79.950 |
| C0 | 3 | 80.875 | 1.536 | 79.101 | 80.362 |
| C1 | 3 | 80.756 | 1.313 | 79.246 | 80.281 |
| C2 | 3 | 79.633 | 0.341 | 79.324 | 79.277 |
| C3 | 3 | 79.670 | 0.353 | 79.349 | 79.321 |

## Every seed

| Arm | Model seed | Accuracy (%) |
|---|---:|---:|
| C0 | 2026092701 | 81.766 |
| C1 | 2026092701 | 81.393 |
| C2 | 2026092701 | 79.576 |
| C3 | 2026092701 | 79.612 |
| C0 | 2026092702 | 79.101 |
| C1 | 2026092702 | 79.246 |
| C2 | 2026092702 | 79.324 |
| C3 | 2026092702 | 79.349 |
| C0 | 2026092703 | 81.757 |
| C1 | 2026092703 | 81.628 |
| C2 | 2026092703 | 79.998 |
| C3 | 2026092703 | 80.048 |
| P0 | 2026092701 | 80.928 |
| P0 | 2026092702 | 79.052 |
| P0 | 2026092703 | 81.599 |

## Paired differences

| Comparison | Seeds | Mean (pp) | Positive seeds |
|---|---:|---:|---:|
| C0 − P0 | 3 | 0.348 | 3 |
| C1 − C0 | 3 | -0.119 | 1 |
| C2 − C1 | 3 | -1.123 | 1 |
| C3 − C2 | 3 | 0.037 | 3 |
| C3 − C0 | 3 | -1.205 | 1 |
| C3 − P0 | 3 | -0.857 | 1 |

Primary success requires all three C3 seeds and clean mean ≥84%; no best-arm replacement.
C0−P0 includes the changed optimizer, schedule, sampling, and additional training. C3−C0 estimates the fixed mechanism increment.
Three seed differences are descriptive evidence, not an automatic statistical significance claim.
Parent training, shared preparation, incremental training, and test costs are referenced separately in resources.json.
